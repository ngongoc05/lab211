package ChangeBaseNumbers.controller;

public class Main {
    public static void main(String[] args) {
      new ChangeBaseNumbersProgramming().run();
    }
}
